/**@<mytype.h>::**/

typedef int token_t;
typedef int flag_t;
